# A3
# Assignment 3
# Blackjack Console Application
- This console-based Java application implements the game of blackjack. Users can interact with the game by providing specific inputs to start a game, instruct the dealer to hit or stand, and end the game.

# Modifying Game Rules
- The game rules in the Blackjack console application can be customized by adjusting the methods in the RulesFactory class. This class is responsible for providing the appropriate rules for the game, which can be tailored to different versions of Blackjack. Here are the three primary rules that can be customized:

# Hit Rule
- Determines the strategy used by the dealer when deciding whether to hit or stand. This rule dictates how the dealer behaves during the game based on the dealer's hand. The following hit rule strategies can be configured:

- BasicHitStrategy: Implements a standard hit strategy where the dealer hits on any hand value less than 17. This is the default strategy used in many Blackjack games.
- Soft17HitStrategy: Defines a strategy where the dealer hits on a soft 17 (a hand value of 17 that includes an Ace counted as 11). This strategy is commonly used in some Blackjack variants to increase the dealer's chances of improving their hand.
# Example
 ``` java
Copy code
public class RulesFactory {

/**
* Creates the rule to use for the dealer's hit behavior.
*
* @return The rule to use (e.g., BasicHitStrategy or Soft17HitStrategy)
  */
  public HitStrategy getHitRule() {
  // Modify the return statement to use a different hit strategy
  return new BasicHitStrategy(); // or return new Soft17HitStrategy();
  }

// Other methods...

}
By customizing the getHitRule() method, you can control the dealer's behavior according to the specific Blackjack rules you want to implement.

-- New Game Rule
- Determines the rule for starting a new game. The possible new game strategies are:

- AmericanNewGameStrategy: New game strategy for American Blackjack.
- InternationalNewGameStrategy: New game strategy for international Blackjack.
# Example
 ``` java
Copy code
public class RulesFactory {

/**
* Creates the rule to use when starting a new game.
*
* @return The rule to use (e.g., AmericanNewGameStrategy or InternationalNewGameStrategy)
  */
  public NewGameStrategy getNewGameRule() {
  // Modify the return statement to use a different new game strategy
  return new AmericanNewGameStrategy(); // or return new InternationalNewGameStrategy();
  }

// Other methods...
} 
# Win Rule
- Specifies the rule for determining the winner. The possible win rules are:

- DealerWinsEqual: Dealer wins in the case of a tie.
- PlayerWinsEqual: Player wins in the case of a tie.
# Example
``` java
Copy code
public class RulesFactory {

/**
* Creates the rule to use for determining the winner.
*
* @return The rule to use (e.g., DealerWinsEqual or PlayerWinsEqual)
  */
  public WinRule getWinRule() {
  // Modify the return statement to use a different win rule
  return new DealerWinsEqual(); // or return new PlayerWinsEqual();
  }

// Other methods...

}
**Building and Running the Application
To build and run the application using Gradle, execute the following command in the root of the project directory:

```bash
Copy code
./gradlew :app:run
The App class contains the main method to start the application.**

 # Usage
- Use the following inputs during the game:

- 'p' to start a game
- 'h' to instruct the dealer to hit
- 's' to instruct to stand
- 'q' to end the game 
- The Idea of Having Two Observer Patterns 
- Having two instances of the Observer pattern in the Blackjack game serves distinct purposes:

# Model-View Separation
- The first instance involves the Game class in the model layer and the Observer interface. Here:

- Subject: The Game class acts as the subject, maintaining the internal state of the game.

- Observers: Various view classes (such as EnglishView and SwedishView in the view layer) implement the Observer interface. These views react to changes in the game's state and update the user interface accordingly.

 - This setup follows the traditional model-view separation principle, ensuring a clear separation between the game's internal logic and its presentation. It enhances modularity and maintainability by allowing changes to the game's logic without affecting how the game is presented to the user.

- User Input Handling
- The second instance focuses on managing user input, involving the InputObserver interface and controller classes (such as Player in the controller layer). Here:

- Subject: User input acts as the subject, capturing player actions and commands.

- Observers: Controller classes implement the InputObserver interface and respond to user inputs, such as starting a new game or making a move.

- This design allows controllers to dynamically react to user actions, ensuring that the game responds appropriately to player decisions and inputs. By separating user input handling from game logic and presentation, this pattern supports a well-organized and responsive game interaction model.

- Although having two instances of the Observer pattern might seem redundant, each serves a unique purpose in maintaining a clear and modular design for the application. This separation of concerns ensures a more maintainable and adaptable codebase.
