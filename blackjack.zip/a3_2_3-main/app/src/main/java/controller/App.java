package controller;

import model.Game;
import view.EnglishView;
import view.View;

/**
 * Starts the application using the console.
 */
public class App {
  /**
   * Starts the game.

  * @param args Not used.
  */
  public static void main(String[] args) {
    // **Refactored**: Creating an EnglishView instance.
    View v = new EnglishView(); // new SwedishView();
    Game g = new Game();
    g.setObserver(v);

    Player ctrl = new Player(g);
    v.setInputObserver(ctrl);

    v.displayWelcomeMessage();
    // **Refactored**: Runs the main game loop.
    while (ctrl.play(v)) {}
    // Continue the game as long as the player chooses to play.
  }

}