package controller;

import model.Game;
import view.View;


/**
 * Scenario controller for playing the game.
 */
public class Player implements InputObserver /* (implements) (req. 4)*/ {
  private Game game;

  public Player(Game game) {
    this.game = game;
  }

  @Override
  public void onInputReceived(int input) {
    // **Refactored**: Improved readability by using a switch statement.
    switch (input) {
      case 'p':
        game.newGame();
        break;
      case 'h':
        game.hit();
        break;
      case 's':
        game.passs();
        break;
      case 'q':
        break;
      default:
    }
  }

  /**
   * **Refactored**: Runs the play use case.
   *
   * @param view The view to use.
   * @return True as long as the game should continue.
   */
  public boolean play(View view) {

    if (game.isGameOver()) {
      view.displayRecurrent(game.getDealerHand(), game.getDealerScore(), game.getPlayerHand(), game.getPlayerScore());
      view.displayGameOver(game.isDealerWinner());
    }

    return view.getInput() != 'q'; //(req. 4)
  }
}
