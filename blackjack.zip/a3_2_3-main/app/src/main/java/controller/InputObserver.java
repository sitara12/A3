package controller;

/**
 * An observer interface for handling input events.
 * Implement this interface to listen for and respond to input events
 * in your application, typically triggered by user actions.
 */
public interface InputObserver {
  /**
     * Called when an input event is received.
     *
     * @param input An integer representing the received input.
     */
  void onInputReceived(int input);
}
