package view;

// import model.Game;

/**
 * Observer class for when a new card is dealt.
 */
public interface Observer {
  void update(Iterable<model.Card> dealerHand, int dealerScore, Iterable<model.Card> playerHand, int playerScore);
}
