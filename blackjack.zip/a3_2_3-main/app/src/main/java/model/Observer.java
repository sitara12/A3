package model;

/**
 * Observer for deck when a new card card is dealt.
 */
public interface Observer {
  void update();
}
