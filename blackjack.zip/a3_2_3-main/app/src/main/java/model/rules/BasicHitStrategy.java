package model.rules;

import model.Player;

/**
 * The BasicHitStrategy class represents a basic strategy for determining when a
 *  player should hit in a game of Blackjack.
 * It implements the HitStrategy interface and defines a hit limit of 17. This means that the player should continue
 * hitting until their hand's score is less than 17.
 */

class BasicHitStrategy implements HitStrategy {

  /**
   * The hit limit represents the threshold score for the player to continue hitting.
   */
  private static final int hitLimit = 17;

  /**
   * Determines whether the player should hit based on the dealer's current hand.
   *
   * @param dealer The dealer in the game.
   * @return true if the player's current score is less than the hit limit, false otherwise.
   */
  public boolean doHit(Player dealer) {
    return dealer.calcScore() < hitLimit;
  }
}

