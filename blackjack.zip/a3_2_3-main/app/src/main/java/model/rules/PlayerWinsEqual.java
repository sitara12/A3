package model.rules;

import model.Player;

/**
 * The PlayerWinsEqual class implements the WinRule interface and represents a rule where the player wins
 * if their score is equal to the dealer's score and both scores are not greater than the specified maximum score.
 */
class PlayerWinsEqual implements WinRule {
    
  /**
     * Checks if the player wins based on the rule that they win if their score is equal to the dealer's score
     * and both scores are not greater than the specified maximum score.
     *
     * @param dealer    The dealer's Player object.
     * @param player    The player's Player object.
     * @param maxScore  The maximum allowed score for the game.
     * @return True if the player wins, false otherwise.
     */
  public boolean checkWin(Player dealer, Player player, int maxScore) {
    if (player.calcScore() > maxScore) {
      return true;
    } else if (dealer.calcScore() > maxScore) {
      return false;
    }
    return player.calcScore() == dealer.calcScore();
  }
}
