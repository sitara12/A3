
package model.rules;

import model.Card;
import model.Player;

/**
 * A class that implements the HitStrategy interface to determine
 * whether a dealer should hit based on the soft 17 rule.
 * In this rule, if the dealer's hand has an Ace counted as 11, the total score is 17.
 * Otherwise, if there is no Ace or the Ace is counted as 1, the total score is exactly 17.
 * The decision to hit or not is made based on these conditions.
 */


public class Soft17 implements HitStrategy {

  /**
     * The hit limit for the soft 17 rule.
     * If the dealer's total score is less than or equal to this limit, they should hit.
     */
  private static final int hitLimit = 17;

  /**
     * Determines whether the dealer should hit or not based on the soft 17 rule.
     *
     * @param dealer The player representing the dealer.
     * @return true if the dealer should hit, false otherwise.
     */

  public boolean doHit(Player dealer) {
    int score = dealer.calcScore();
    boolean hasAce = false;

    for (Card c : dealer.getHand()) {
      if (c.getValue() == Card.Value.Ace) {
        hasAce = true;
        break;
      }
    }

    if (hasAce) {
      // Soft 17: Ace is counted as 11, and the total score is 17
      return score <= hitLimit;
    } else {
      // Hard 17: No Ace, the total score is exactly 17
      return score < hitLimit;
    }
  }
}
