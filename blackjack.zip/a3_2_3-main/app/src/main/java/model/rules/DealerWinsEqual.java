package model.rules;

import model.Player;

/**
  * The `DealerWinsEqual` class implements the 
  `WinRule` interface and defines a rule for 
  determining the winner in a game of Blackjack when both the dealer and the 
  player have scores less than or equal to the maximum allowed score. 
  * In this rule, the dealer wins if the player and dealer have equal
   scores, or if both have scores exceeding the maximum allowed score.
   */


class DealerWinsEqual implements WinRule {

  /**
   * Checks if the dealer wins according to the defined rule.
   *
   * @param dealer    The `Player` representing the dealer.
   * @param player    The `Player` representing the player.
   * @param maxScore  The maximum allowed score in the game.
   * @return `true` if the dealer wins according to the rule, `false` otherwise.
   */
  public boolean checkWin(Player dealer, Player player, int maxScore) {
    if (player.calcScore() > maxScore) {
      return true;
    } else if (dealer.calcScore() > maxScore) {
      return false;
    }
    return player.calcScore() <= dealer.calcScore();
  }
}
