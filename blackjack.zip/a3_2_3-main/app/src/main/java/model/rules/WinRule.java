package model.rules;

import model.Player;

/**
 * An interface for defining winning rules in a card game.
 * Implementations of this interface determine who wins between the dealer and the player.
 */
public interface WinRule {

     /**
     * Checks who wins the game based on specific criteria defined by the implementation.
     *
     * @param dealer   The player representing the dealer.
     * @param player   The player representing the player.
     * @param maxScore The maximum allowed score in the game.
     * @return true if the dealer wins, false otherwise.
     * 
     * 
     */boolean checkWin(Player dealer, Player player, int maxScore);
}
