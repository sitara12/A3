package model.rules;

import model.Dealer;
import model.Deck;
import model.Player;

/**
 * This class represents an international new game strategy for a card game.
 * It deals two cards to the player and one card to the dealer as the initial game setup.
 */
class InternationalNewGameStrategy implements NewGameStrategy {

  /**
   * Implements the new game strategy by dealing cards to the player and dealer.
   *
   * @param deck The deck of cards to draw from.
   * @param dealer The dealer object.
   * @param player The player object.
   * @return true if the new game setup was successful, false otherwise.
   */
  public boolean newGame(Deck deck, Dealer dealer, Player player) {
    //modified this method
    deck.dealCardToPlayer(player, true);
    deck.dealCardToPlayer(dealer, true);
    deck.dealCardToPlayer(player, true);

    return true;
  }
}
